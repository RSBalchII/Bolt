import * as fs from 'fs';
import * as path from 'path';
import { db } from '../../core/db.js';
import { SearchResult } from './search.js';
import { getMirrorPath, MIRRORED_BRAIN_PATH } from '../mirror/mirror.js';
import { NOTEBOOK_DIR } from '../../config/paths.js';

interface ContextWindow {
    compoundId: string;
    source: string;
    start: number;
    end: number;
    originalResults: SearchResult[];
}

export class ContextInflator {

    /**
     * Inflate search results into expanded Context Windows.
     *
     * Architecture: Atoms are POINTERS — the DB stores entity labels + byte coordinates.
     * Content lives in the original files on disk (mirrored). This method:
     *   1. Skips results already inflated by inflateFromAtomPositions (read from disk)
     *   2. For results with compound coordinates: resolves file path → reads from disk with radial expansion
     *   3. Falls back to compound_body in DB only if the disk file doesn't exist
     *
     * Progressive Inflation: Top results get larger radius for better budget allocation.
     *
     * The DB is a lightweight routing layer. Actual content comes from the filesystem.
     */
    static async inflate(results: SearchResult[], totalBudget?: number, radius: number = 0): Promise<SearchResult[]> {
        if (results.length === 0) return [];

        // 0. Pre-sort results by score to ensure top items get priority
        results.sort((a, b) => (b.score || 0) - (a.score || 0));

        // Dynamic radius: if caller didn't specify, scale based on budget and result count
        // Target: fill the budget evenly across results
        let baseRadius = radius;
        if (baseRadius <= 0 && totalBudget && results.length > 0) {
            const targetWindowSize = Math.floor(totalBudget / Math.min(results.length, 10));
            baseRadius = Math.max(200, Math.floor(targetWindowSize / 2));
            // Cap to prevent massive reads
            baseRadius = Math.min(baseRadius, 5000);
        }
        // Absolute minimum radius so we don't get zero-width slices
        baseRadius = Math.max(baseRadius, 200);

        // Cache: compound_id → { filePath, provenance } so we only look up paths once
        const compoundPathCache = new Map<string, { filePath: string, provenance: string } | null>();

        const processedResults: SearchResult[] = [];
        let inflatedFromDisk = 0;
        let inflatedFromDb = 0;
        let skippedAlready = 0;
        let skippedNoCoords = 0;

        // Progressive inflation: allocate more budget to top results
        // Top 10% get 2x radius, next 40% get 1.5x, rest get 1x
        const topTenPercent = Math.max(1, Math.floor(results.length * 0.1));
        const nextFortyPercent = Math.floor(results.length * 0.4);

        for (let i = 0; i < results.length; i++) {
            const res = results[i];

            // Progressive radius allocation based on rank
            let radiusMultiplier = 1.0;
            if (i < topTenPercent) {
                radiusMultiplier = 2.0;  // Top 10% get 2x radius
            } else if (i < topTenPercent + nextFortyPercent) {
                radiusMultiplier = 1.5;  // Next 40% get 1.5x
            }
            // Rest get 1.0x (base)

            const effectiveRadius = Math.floor(baseRadius * radiusMultiplier);

            // 1. Skip results already inflated from disk (e.g., by inflateFromAtomPositions)
            if (res.is_inflated) {
                processedResults.push(res);
                skippedAlready++;
                continue;
            }

            // 2. Skip if no compound coordinates — use as-is (entity label)
            if (!res.compound_id || res.start_byte === undefined || res.end_byte === undefined) {
                processedResults.push(res);
                skippedNoCoords++;
                continue;
            }

            try {
                // 3. Try to inflate from DISK (mirrored file)
                const diskContent = await this.inflateFromDisk(res, effectiveRadius, compoundPathCache);

                if (diskContent !== null) {
                    processedResults.push({
                        ...res,
                        content: `...${diskContent}...`,
                        is_inflated: true
                    });
                    inflatedFromDisk++;
                    continue;
                }

                // 4. Fallback: inflate from compound_body in DB (file may not exist yet)
                const dbContent = await this.inflateFromCompoundBody(res, effectiveRadius);

                if (dbContent !== null) {
                    processedResults.push({
                        ...res,
                        content: `...${dbContent}...`,
                        is_inflated: true
                    });
                    inflatedFromDb++;
                    continue;
                }

                // 5. Nothing worked — use raw result as-is
                processedResults.push(res);
            } catch (e) {
                console.error(`[ContextInflator] Failed to inflate result for ${res.source}`, e);
                processedResults.push(res);
            }
        }

        console.log(`[ContextInflator] inflate(): ${inflatedFromDisk} from disk, ${inflatedFromDb} from DB fallback, ${skippedAlready} already inflated, ${skippedNoCoords} no coordinates. Base Radius: ${baseRadius}`);

        return processedResults; // Already sorted
    }

    /**
     * Helper: Expand logical window to nearest sentence boundary
     */
    private static snapToSentenceBoundary(content: string, targetStart: number, targetEnd: number): { start: number, end: number, text: string } {
        // We look for sentence terminators: . ! ? followed by space or newline
        // effectively we are operating on a "Chunk" of text that is likely larger than the target window
        // targetStart/End are indices relative to the "content" string provided.

        // 1. Snap Start (Move backwards to find previous sentence end)
        let snappedStart = 0;
        // Search backwards from targetStart for a sentence terminator
        // We want the Start of the *current* sentence, so we look for the *end* of the *previous* sentence
        // validation: ensure we don't go back too far? Content is already a window.

        // Simple heuristic: valid sentence starts after (.!?)\s
        const preceeding = content.substring(0, targetStart);
        const matchStart = preceeding.match(/([.!?]\s|\n\s*\n)(?=[^.!?\n]*$)/);

        if (matchStart && matchStart.index !== undefined) {
            snappedStart = matchStart.index + matchStart[0].length;
        } else {
            // If no sentence end found, maybe just snap to first spaces
            const spaceMatch = preceeding.match(/\s(?=[^\s]*$)/);
            if (spaceMatch && spaceMatch.index !== undefined) {
                snappedStart = spaceMatch.index + 1;
            } else {
                snappedStart = 0; // consistent with start of string
            }
        }

        // 2. Snap End (Move forwards to find next sentence end)
        let snappedEnd = content.length;
        const succeeding = content.substring(targetEnd);
        // Look for the *first* sentence terminator
        const matchEnd = succeeding.match(/([.!?]\s|\n\s*\n)/);

        if (matchEnd && matchEnd.index !== undefined) {
            snappedEnd = targetEnd + matchEnd.index + 1; // Include the punctuation
        } else {
            // Fallback to next space
            const spaceMatch = succeeding.match(/\s/);
            if (spaceMatch && spaceMatch.index !== undefined) {
                snappedEnd = targetEnd + spaceMatch.index;
            }
        }

        return {
            start: snappedStart,
            end: snappedEnd,
            text: content.substring(snappedStart, snappedEnd).trim()
        };
    }

    /**
     * Inflate a single result from the mirrored file on disk.
     * Returns the extracted content string, or null if the file doesn't exist.
     */
    private static async inflateFromDisk(
        res: SearchResult,
        radius: number,
        pathCache: Map<string, { filePath: string, provenance: string } | null>
    ): Promise<string | null> {
        if (!res.compound_id) return null;

        // Look up the compound's file path (cached)
        let pathInfo = pathCache.get(res.compound_id);
        if (pathInfo === undefined) {
            // First time seeing this compound — look up in DB
            try {
                const result = await db.run(`SELECT path, provenance FROM compounds WHERE id = $1`, [res.compound_id]);
                if (result.rows && result.rows.length > 0) {
                    pathInfo = { filePath: result.rows[0].path as string, provenance: result.rows[0].provenance as string };
                } else {
                    pathInfo = null;
                }
            } catch {
                pathInfo = null;
            }
            pathCache.set(res.compound_id, pathInfo);
        }

        if (!pathInfo) return null;

        // Resolve to absolute path: try mirrored file first, then original
        const mirrorPath = getMirrorPath(pathInfo.filePath, pathInfo.provenance);
        let absolutePath = mirrorPath;

        if (!fs.existsSync(mirrorPath)) {
            absolutePath = path.isAbsolute(pathInfo.filePath)
                ? pathInfo.filePath
                : path.join(NOTEBOOK_DIR, pathInfo.filePath);
        }

        if (!fs.existsSync(absolutePath)) return null;

        try {
            const stats = fs.statSync(absolutePath);
            const fileSize = stats.size;

            // Over-read by 1000 bytes on each side to find boundaries
            const lookahead = 1000;
            const rawStart = Math.max(0, (res.start_byte ?? 0) - radius - lookahead);
            const rawEnd = Math.min(fileSize, (res.end_byte ?? fileSize) + radius + lookahead);
            const chunkLength = rawEnd - rawStart;

            if (chunkLength <= 0) return null;

            const buffer = Buffer.alloc(chunkLength);
            const fd = fs.openSync(absolutePath, 'r');
            try {
                fs.readSync(fd, buffer, 0, chunkLength, rawStart);
            } finally {
                fs.closeSync(fd);
            }

            const rawContent = buffer.toString('utf-8');

            // Calculate where our "Ideal" window sits within this raw buffer
            // ideal window start (relative to buffer) = (res.start - radius) - rawStart
            // But actually we just want to snap around the center roughly?
            // Let's rely on snapToSentenceBoundary relative to the *whole buffer*.
            // We want the text that *contains* the hit (res.start...res.end).

            // Relative offsets of the HIT within the buffer
            const hitStartRel = Math.max(0, (res.start_byte ?? 0) - rawStart);
            const hitEndRel = Math.min(chunkLength, (res.end_byte ?? fileSize) - rawStart);

            // Our "Target" window is the hit +/- radius
            const targetStartRel = Math.max(0, hitStartRel - radius);
            const targetEndRel = Math.min(chunkLength, hitEndRel + radius);

            // Snap!
            const snapped = this.snapToSentenceBoundary(rawContent, targetStartRel, targetEndRel);

            return snapped.text.length > 0 ? snapped.text : null;

        } catch {
            return null;
        }
    }

    /**
     * Fallback: inflate from compound_body stored in the DB.
     * Used when the disk file doesn't exist (e.g., during initial ingest before mirror).
     */
    private static async inflateFromCompoundBody(res: SearchResult, radius: number): Promise<string | null> {
        if (!res.compound_id) return null;

        try {
            const result = await db.run(`SELECT compound_body FROM compounds WHERE id = $1`, [res.compound_id]);
            if (!result.rows || result.rows.length === 0) return null;

            const compoundBody = result.rows[0].compound_body as string;
            if (!compoundBody) return null;

            // Similar logic to inflateFromDisk but with string
            const lookahead = 1000;
            const bodyLen = compoundBody.length; // Approximate byte check? JS strings are UTF16-ish. 
            // Assuming 1 char = 1 byte index for simplicity roughly, or we blindly trust indices.

            // Over-read logic
            const rawStart = Math.max(0, (res.start_byte ?? 0) - radius - lookahead);
            const rawEnd = Math.min(bodyLen, (res.end_byte ?? bodyLen) + radius + lookahead);

            const rawChunk = compoundBody.substring(rawStart, rawEnd);

            // Relative offsets
            const hitStartRel = Math.max(0, (res.start_byte ?? 0) - rawStart);
            const hitEndRel = Math.min(rawChunk.length, (res.end_byte ?? bodyLen) - rawStart);

            const targetStartRel = Math.max(0, hitStartRel - radius);
            const targetEndRel = Math.min(rawChunk.length, hitEndRel + radius);

            const snapped = this.snapToSentenceBoundary(rawChunk, targetStartRel, targetEndRel);

            return snapped.text.length > 0 ? snapped.text : null;
        } catch {
            return null;
        }
    }

    /**
     * Get atom locations for Elastic Context sizing
     * Returns the raw positions so we can calculate density/hits BEFORE inflating
     */
    static async getAtomLocations(term: string, limit: number = 100, options: { buckets?: string[], provenance?: string } = {}): Promise<{ compoundId: string, byteOffset: number, filePath: string, timestamp: number, provenance: string }[]> {
        // Atoms are stored with # prefix, but we might search without
        const termWithHash = term.startsWith('#') ? term : `#${term}`;
        const termWithoutHash = term.startsWith('#') ? term.slice(1) : term;

        let query = `
            SELECT ap.compound_id, ap.byte_offset, c.path, c.timestamp, c.provenance
            FROM atom_positions ap
            JOIN compounds c ON ap.compound_id = c.id
            WHERE 
               (LOWER(ap.atom_label) = LOWER($1) 
               OR LOWER(ap.atom_label) = LOWER($2)
               OR ap.atom_label ILIKE $3)
        `;

        const params: any[] = [termWithHash, termWithoutHash, `${termWithoutHash}%`];

        // Apply Provenance Filter
        if (options.provenance && options.provenance !== 'all') {
            params.push(options.provenance);
            query += ` AND c.provenance = $${params.length}`;
        }

        // Apply Bucket Filter (Check if compound contains ANY atom with the bucket)
        if (options.buckets && options.buckets.length > 0) {
            params.push(options.buckets);
            // We join atoms to check if any atom in this compound has the bucket
            // optimize: use EXISTS instead of joining widely
            query += ` AND EXISTS (
                SELECT 1 FROM atoms a 
                WHERE a.compound_id = c.id 
                AND EXISTS (
                    SELECT 1 FROM unnest(a.buckets) as b WHERE b = ANY($${params.length})
                )
            )`;
        }

        query += ` ORDER BY c.timestamp DESC LIMIT $${params.length + 1}`;
        params.push(limit);

        try {
            const result = await db.run(query, params);
            if (!result.rows) return [];

            return result.rows.map((row: any) => ({
                compoundId: row.compound_id as string,
                byteOffset: row.byte_offset as number,
                filePath: row.path as string,
                timestamp: row.timestamp as number,
                provenance: row.provenance as string
            }));
        } catch (e) {
            console.error(`[ContextInflator] Check locations failed for ${term}`, e);
            return [];
        }
    }

    /**
     * Radial Inflation from Atom Positions (Lazy Molecule Architecture)
     * Searches atom_positions for keyword occurrences and expands radially
     * 
     * @param searchTerm - The atom/keyword to search for
     * @param radius - How many bytes to expand in each direction (default 500)
     * @param maxResults - Maximum results to return
     */
    static async inflateFromAtomPositions(
        searchTerm: string,
        radius: number = 500,
        maxResults: number = 20,
        maxWindowSize: number = radius * 3, // Default cap if not provided
        options: { buckets?: string[], provenance?: string } = {}
    ): Promise<SearchResult[]> {
        const results: SearchResult[] = [];

        try {
            // Find all positions where this atom appears
            // Atoms are stored with # prefix (e.g. "#Rob") but search terms come without
            // So we search for both formats: "#Rob" and "Rob"
            const termWithHash = searchTerm.startsWith('#') ? searchTerm : `#${searchTerm}`;
            const termWithoutHash = searchTerm.startsWith('#') ? searchTerm.slice(1) : searchTerm;

            let query = `
                SELECT ap.compound_id, ap.byte_offset, c.path, c.timestamp, c.provenance
                FROM atom_positions ap
                JOIN compounds c ON ap.compound_id = c.id
                WHERE (LOWER(ap.atom_label) = LOWER($1) OR LOWER(ap.atom_label) = LOWER($2))
            `;

            const params: any[] = [termWithHash, termWithoutHash];

            // Apply Provenance Filter
            if (options.provenance && options.provenance !== 'all') {
                params.push(options.provenance);
                query += ` AND c.provenance = $${params.length}`;
            }

            // Apply Bucket Filter
            if (options.buckets && options.buckets.length > 0) {
                params.push(options.buckets);
                query += ` AND EXISTS (
                    SELECT 1 FROM atoms a 
                    WHERE a.compound_id = c.id 
                    AND EXISTS (
                        SELECT 1 FROM unnest(a.buckets) as b WHERE b = ANY($${params.length})
                    )
                )`;
            }

            query += ` ORDER BY c.timestamp DESC LIMIT $${params.length + 1}`;
            params.push(maxResults * 2);

            const positionsResult = await db.run(query, params);
            if (!positionsResult.rows || positionsResult.rows.length === 0) {
                return [];
            }

            // Group by compound to avoid duplicate reads
            const compoundPositions = new Map<string, { positions: number[], filePath: string, timestamp: number, provenance: string }>();

            for (const row of positionsResult.rows) {
                const compoundId = row.compound_id as string;
                const byteOffset = row.byte_offset as number;
                const dbPath = row.path as string;
                const timestamp = row.timestamp as number;
                const provenance = row.provenance as string;

                if (!compoundPositions.has(compoundId)) {
                    compoundPositions.set(compoundId, {
                        positions: [],
                        filePath: dbPath,
                        timestamp,
                        provenance
                    });
                }
                compoundPositions.get(compoundId)!.positions.push(byteOffset);
            }

            // Radially inflate from each position, MERGING overlapping windows
            // Read content from MIRRORED FILES on disk, not from database
            // Radially inflate from each position, MERGING overlapping windows
            // Read content from MIRRORED FILES on disk, not from database
            // [Optimization] Parallelize file I/O to reduce latency
            const inflationPromises = Array.from(compoundPositions.entries()).map(async ([compoundId, data]) => {
                // Resolve the file path - try mirrored file first, then original
                const mirrorPath = getMirrorPath(data.filePath, data.provenance);
                let absolutePath = mirrorPath;

                // If mirror doesn't exist, try original path
                if (!fs.existsSync(mirrorPath)) {
                    absolutePath = path.isAbsolute(data.filePath)
                        ? data.filePath
                        : path.join(NOTEBOOK_DIR, data.filePath);
                }

                // Skip if file doesn't exist
                if (!fs.existsSync(absolutePath)) {
                    // console.warn(`[ContextInflator] File not found: ${absolutePath}`);
                    return [];
                }

                // Read file stats to get size for window clamping
                let fileSize = 0;
                try {
                    const stats = await fs.promises.stat(absolutePath);
                    fileSize = stats.size;
                } catch (e) {
                    console.warn(`[ContextInflator] Failed to stat file: ${absolutePath}`);
                    return [];
                }

                // Calculate raw windows for all positions using file size
                const rawWindows = data.positions.map(byteOffset => ({
                    start: Math.max(0, byteOffset - radius),
                    end: Math.min(fileSize, byteOffset + radius),
                    offset: byteOffset
                }));

                // Sort by start position for merge algorithm
                rawWindows.sort((a, b) => a.start - b.start);

                // Merge overlapping OR ADJACENT windows
                // Molecules from same compound within 500 bytes should be merged
                const MERGE_GAP_THRESHOLD = 500; // Merge windows within 500 bytes of each other
                
                const mergedWindows: { start: number; end: number; offsets: number[] }[] = [];
                for (const window of rawWindows) {
                    const last = mergedWindows[mergedWindows.length - 1];
                    // Merge if overlapping OR adjacent (within gap threshold)
                    if (last && (window.start <= last.end || (window.start - last.end) < MERGE_GAP_THRESHOLD)) {
                        const newEnd = Math.max(last.end, window.end);
                        if ((newEnd - last.start) <= maxWindowSize) {
                            last.end = newEnd;
                            last.offsets.push(window.offset);
                        } else {
                            mergedWindows.push({ start: window.start, end: window.end, offsets: [window.offset] });
                        }
                    } else {
                        mergedWindows.push({ start: window.start, end: window.end, offsets: [window.offset] });
                    }
                }

                const compoundResults: SearchResult[] = [];
                let fd: fs.promises.FileHandle | null = null;

                try {
                    fd = await fs.promises.open(absolutePath, 'r');

                    for (const window of mergedWindows) {
                        const chunkLength = window.end - window.start;
                        if (chunkLength <= 0) continue;

                        const buffer = Buffer.alloc(chunkLength);
                        // fs.promises.read returns { bytesRead, buffer }
                        await fd.read(buffer, 0, chunkLength, window.start);

                        let inflatedContent = buffer.toString('utf-8');

                        // Clean up partial words at boundaries
                        if (window.start > 0) {
                            const firstSpace = inflatedContent.indexOf(' ');
                            if (firstSpace !== -1 && firstSpace < 50) {
                                inflatedContent = inflatedContent.substring(firstSpace + 1);
                            }
                        }
                        if (window.end < fileSize) {
                            const lastSpace = inflatedContent.lastIndexOf(' ');
                            if (lastSpace > inflatedContent.length - 50) {
                                inflatedContent = inflatedContent.substring(0, lastSpace);
                            }
                        }

                        if (inflatedContent.trim().length === 0) continue;

                        compoundResults.push({
                            id: `virtual_${compoundId}_${window.start}_${window.end}`,
                            content: `...${inflatedContent}...`,
                            source: data.filePath,
                            timestamp: data.timestamp,
                            buckets: ['core'],
                            tags: [searchTerm],
                            epochs: '',
                            provenance: data.provenance,
                            score: 500, // Partial score, sorted later
                            compound_id: compoundId,
                            start_byte: window.start,
                            end_byte: window.end,
                            is_inflated: true
                        });
                    }
                } catch (err) {
                    console.warn(`[ContextInflator] Error reading file ${absolutePath}:`, err);
                } finally {
                    if (fd) await fd.close();
                }

                return compoundResults;
            });

            const resultsArrays = await Promise.all(inflationPromises);
            // Flatten results
            resultsArrays.forEach(arr => results.push(...arr));

            // Sort by score/relevance (simple approximation for now)
            results.sort((a, b) => (b.score || 0) - (a.score || 0));

            // Slice to maxResults
            if (results.length > maxResults) {
                results.length = maxResults;
            }

            console.log(`[ContextInflator] Radially inflated ${results.length} merged virtual molecules for "${searchTerm}"`);
            return results;

        } catch (e) {
            console.error(`[ContextInflator] Failed to inflate from atom positions: `, e);
            return [];
        }
    }

    /**
     * Fetch additional context to fill the token budget with less directly connected but still relevant data
     */
    private static async fetchAdditionalContext(baseResults: SearchResult[], remainingBudget: number): Promise<SearchResult[]> {
        // Only run if we have significant budget left (> 50% of typical large window)
        // or if we have very primitive results.
        if (remainingBudget < 1000) return [];

        // Extract tags and buckets from base results to find related content
        const allTags = new Set<string>();
        const allBuckets = new Set<string>();

        // We only consider tags/buckets from TOP results to avoid drift
        const topResults = baseResults.slice(0, 5);
        for (const result of topResults) {
            if (result.tags) {
                result.tags.forEach(tag => allTags.add(tag));
            }
            if (result.buckets) {
                result.buckets.forEach(bucket => allBuckets.add(bucket));
            }
        }

        // Convert sets to arrays for use in queries
        const tagsArray = Array.from(allTags);
        const bucketsArray = Array.from(allBuckets);

        // Query for related content that shares tags or buckets but wasn't in the original results
        let query = `
            SELECT id, content, source_path as source, timestamp,
    buckets, tags, epochs, provenance, simhash as molecular_signature,
    100 as score  --Lower score for less directly connected content
            FROM atoms
WHERE `;

        const params: any[] = [];
        const conditions: string[] = [];

        // Add conditions for tags if we have any
        if (tagsArray.length > 0) {
            conditions.push(`EXISTS(
    SELECT 1 FROM unnest(tags) as tag WHERE tag = ANY($${params.length + 1})
)`);
            params.push(tagsArray);
        }

        // Add conditions for buckets if we have any
        if (bucketsArray.length > 0) {
            const bucketParamIndex = params.length + 1;
            conditions.push(`EXISTS(
    SELECT 1 FROM unnest(buckets) as bucket WHERE bucket = ANY($${bucketParamIndex})
)`);
            params.push(bucketsArray);
        }

        // Combine conditions with OR (so we get content that matches either tags OR buckets)
        let queryConditions = '';
        if (conditions.length > 0) {
            queryConditions = `(${conditions.join(' OR ')})`;
        } else {
            // If no tags or buckets to match, just get some random content
            queryConditions = 'TRUE';
        }

        // Exclude original results
        const originalIds = baseResults.map(r => r.id);
        let fullQuery = query + queryConditions;
        if (originalIds.length > 0) {
            const excludeParamIndex = params.length + 1;
            fullQuery += ` AND id != ALL($${excludeParamIndex})`;
            params.push(originalIds);
        }

        // Limit to avoid fetching too much
        fullQuery += ` ORDER BY timestamp DESC LIMIT 10`;

        try {
            const result = await db.run(fullQuery, params);
            if (!result.rows) return [];

            // Convert rows to SearchResult objects
            const additionalResults: SearchResult[] = result.rows.map((row: any) => ({
                id: row.id,
                content: row.content,
                source: row.source,
                timestamp: row.timestamp,
                buckets: row.buckets,
                tags: row.tags,
                epochs: row.epochs,
                provenance: row.provenance,
                molecular_signature: row.simhash,
                score: row.score || 100, // Default score if not provided
                is_inflated: true
            }));

            // Further filter and truncate content to fit the remaining budget
            let totalChars = 0;
            const filteredResults: SearchResult[] = [];

            for (const result of additionalResults) {
                if (!result.content) continue;

                const availableSpace = remainingBudget - totalChars;
                if (availableSpace <= 0) break;

                if (result.content.length <= availableSpace) {
                    // If the content fits entirely, add it
                    filteredResults.push(result);
                    totalChars += result.content.length;
                } else {
                    // If the content is too large, truncate it to fit
                    const truncatedContent = result.content.substring(0, availableSpace);
                    filteredResults.push({
                        ...result,
                        content: truncatedContent
                    });
                    totalChars += truncatedContent.length;
                    break; // Budget is filled
                }
            }

            console.log(`[ContextInflator] Fetched ${filteredResults.length} additional results to fill budget`);
            return filteredResults;
        } catch (e) {
            console.error(`[ContextInflator] Failed to fetch additional context: `, e);
            return [];
        }
    }
}