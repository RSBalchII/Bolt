/**
 * Search Utilities Module — "The Tools"
 *
 * Types, interfaces, Hamming distance calculation, result formatting,
 * and display helpers used across the search subsystem.
 * Extracted from search.ts for clean separation of concerns.
 */

import { config } from '../../config/index.js';
import { composeRollingContext } from '../../core/inference/context_manager.js';
import { nativeModuleManager } from '../../utils/native-module-manager.js';
import { SemanticCategory } from '../../types/taxonomy.js';
import { ContextInflator } from './context-inflator.js';
import * as fs from 'fs';
import * as path from 'path';
import { getMirrorPath, MIRRORED_BRAIN_PATH } from '../mirror/mirror.js';
import { NOTEBOOK_DIR } from '../../config/paths.js';

/**
 * Coalesced Snippet - Merged atoms from same file within proximity threshold
 */
export interface CoalescedSnippet {
  source: string;
  compoundId: string;
  startByte: number;
  endByte: number;
  timestamp: number;
  content: string;
  sourceAtoms: SearchResult[];  // Track which atoms were merged
  relevanceScore: number;
  provenance: string;
  tags: string[];
}

export interface SearchResult {
    id: string;
    content: string;
    source: string;
    timestamp: number;
    buckets: string[];
    tags: string[];
    epochs: string;
    provenance: string;
    score: number;
    sequence?: number; // Added for Bright Node continuity
    molecular_signature?: string;  // V4 Nomenclature (formerly simhash)
    frequency?: number; // Number of times this content was found (for deduplication)
    temporal_state?: { // Information about temporal aspects of duplicates
        first_seen: number;
        last_seen: number;
        occurrence_count: number;
        timestamps: number[]; // Array of all timestamps when this content or similar was found
    };
    // Atomic Fields
    compound_id?: string;
    start_byte?: number;
    end_byte?: number;
    type?: string;
    numeric_value?: number;
    numeric_unit?: string;
    is_inflated?: boolean;
    // Semantic Fields
    semanticCategories?: SemanticCategory[];
    relatedEntities?: string[];
    // Context Provenance (Standard 107)
    temporal_weight?: number; // Exponential decay factor e^(-λΔt)
    decay_factor?: number; // Lambda * age in seconds
    simhash_distance?: number; // Hamming distance from query (0-64)
    structural_similarity?: number; // 1 - (distance/64)
    association_path?: string[]; // Tags that connected this result to query
    retrieved_at?: number; // When this result was retrieved (for caching)
}

/**
 * Helper: Calculate Hamming Distance between two hex strings
 * Uses the native module or fallback if available
 */
export function getHammingDistance(hashA: string, hashB: string): number {
    try {
        // Validate inputs before processing
        if (!hashA || !hashB) {
            console.warn('[Search] Invalid hash inputs for Hamming distance calculation:', { hashA, hashB });
            return 64; // Max distance on error (assume different)
        }

        // Ensure valid hex strings
        if (!/^[0-9a-fA-F]+$/.test(hashA) || !/^[0-9a-fA-F]+$/.test(hashB)) {
            console.warn('[Search] Invalid hex string format for Hamming distance:', { hashA, hashB });
            return 64; // Max distance on error (assume different)
        }

        const a = BigInt(`0x${hashA}`);
        const b = BigInt(`0x${hashB}`);

        // Force JS fallback to prevent native module crashes (ECONNRESET/Segfault debugging)
        /*
        const native = nativeModuleManager.loadNativeModule('ece_native', 'ece_native.node'); // Ensure loaded
    
        // Check if we're using fallback implementation
        const isUsingFallback = nativeModuleManager.isUsingFallback('ece_native');
        if (isUsingFallback) {
          console.log('[Search] Using fallback implementation for native module distance calculation');
        }
    
        if (native && native.distance) {
          try {
            // Add timeout protection for native calls to prevent hanging
            const result = native.distance(a, b);
            if (typeof result !== 'number') {
              console.warn('[Search] Unexpected result type from native distance function:', typeof result);
              return 64;
            }
            return result;
          } catch (nativeError) {
            console.error('[Search] Native module distance function failed:', nativeError);
            // Fallback to JavaScript implementation if native call fails
            let xor = a ^ b;
            let count = 0;
            while (xor > 0n) {
              xor &= (xor - 1n);
              count++;
            }
            return count;
          }
        } else {
        */
        // JavaScript fallback implementation
        let xor = a ^ b;
        let count = 0;
        while (xor > 0n) {
            xor &= (xor - 1n);
            count++;
        }
        return count;
        //}

    } catch (e) {
        console.error('[Search] Hamming distance calculation failed:', e);
        return 64; // Max distance on error (assume different)
    }
}

/**
 * Helper: safely extract array from possibly undefined input
 */
export function getItems(input: string[] | undefined): string[] {
    return Array.isArray(input) ? input : [];
}

/**
 * Coalesce atoms by proximity - merges nearby atoms from same source file
 * into coherent snippets for better LLM consumption
 *
 * @param results - Search results to coalesce
 * @param proximityThreshold - Bytes within which to merge atoms (default 500)
 * @returns Coalesced snippets with expanded content
 */
export async function coalesceByProximity(
  results: SearchResult[],
  proximityThreshold: number = 500
): Promise<CoalescedSnippet[]> {
  // Group by compound_id (source file)
  const byCompound = new Map<string, SearchResult[]>();
  results.forEach(r => {
    if (!r.compound_id || !r.source) return;
    if (!byCompound.has(r.compound_id)) byCompound.set(r.compound_id, []);
    byCompound.get(r.compound_id)!.push(r);
  });

  const coalesced: CoalescedSnippet[] = [];
  let mergedCount = 0;

  for (const [compoundId, atoms] of byCompound.entries()) {
    if (atoms.length === 0) continue;

    // Sort by byte offset
    atoms.sort((a, b) => (a.start_byte || 0) - (b.start_byte || 0));

    // Merge atoms within proximity threshold
    const merged: CoalescedSnippet[] = [];
    let current: CoalescedSnippet | null = null;

    for (const atom of atoms) {
      const atomStart = atom.start_byte || 0;
      const atomEnd = atom.end_byte || 0;

      if (!current) {
        current = {
          source: atom.source!,
          compoundId,
          startByte: atomStart,
          endByte: atomEnd,
          timestamp: atom.timestamp,
          content: atom.content,
          sourceAtoms: [atom],
          relevanceScore: atom.score,
          provenance: atom.provenance || 'internal',
          tags: atom.tags || []
        };
      } else {
        const gap = atomStart - current.endByte;

        // Merge if overlapping or within proximity threshold
        if (gap <= proximityThreshold) {
          // Extend window
          current.endByte = Math.max(current.endByte, atomEnd);
          current.sourceAtoms.push(atom);
          current.relevanceScore = Math.max(current.relevanceScore, atom.score);
          current.timestamp = Math.min(current.timestamp, atom.timestamp); // Use earliest timestamp
          current.tags = Array.from(new Set([...current.tags, ...(atom.tags || [])]));
          mergedCount++;
        } else {
          // Push current and start new
          merged.push(current);
          current = {
            source: atom.source!,
            compoundId,
            startByte: atomStart,
            endByte: atomEnd,
            timestamp: atom.timestamp,
            content: atom.content,
            sourceAtoms: [atom],
            relevanceScore: atom.score,
            provenance: atom.provenance || 'internal',
            tags: atom.tags || []
          };
        }
      }
    }
    if (current) merged.push(current);

    // Re-inflate content from disk with expanded windows
    for (const snippet of merged) {
      try {
        const inflatedContent = await inflateSnippetFromDisk(snippet);
        if (inflatedContent) {
          snippet.content = inflatedContent;
        }
      } catch (e) {
        console.warn(`[Coalesce] Failed to inflate snippet from ${snippet.source}`, e);
      }
    }

    coalesced.push(...merged);
  }

  console.log(`[Coalesce] Merged ${results.length} atoms -> ${coalesced.length} snippets (${mergedCount} merges)`);
  return coalesced;
}

/**
 * Inflate a coalesced snippet from disk
 */
async function inflateSnippetFromDisk(snippet: CoalescedSnippet): Promise<string | null> {
  try {
    // Resolve file path - try mirrored first
    const mirrorPath = getMirrorPath(snippet.source, snippet.provenance);
    let absolutePath = mirrorPath;

    if (!fs.existsSync(mirrorPath)) {
      absolutePath = path.isAbsolute(snippet.source)
        ? snippet.source
        : path.join(NOTEBOOK_DIR, snippet.source);
    }

    if (!fs.existsSync(absolutePath)) return null;

    const stats = fs.statSync(absolutePath);
    const fileSize = stats.size;

    // Clamp to file bounds
    const start = Math.max(0, snippet.startByte);
    const end = Math.min(fileSize, snippet.endByte);

    if (start >= end) return null;

    // Read content
    const buffer = Buffer.alloc(end - start);
    const fd = fs.openSync(absolutePath, 'r');
    try {
      fs.readSync(fd, buffer, 0, end - start, start);
    } finally {
      fs.closeSync(fd);
    }

    let content = buffer.toString('utf-8');

    // Snap to sentence boundaries for coherence
    content = snapToSentenceBoundaries(content, 0, content.length).text;

    // Add ellipsis to indicate truncation
    if (start > 0) content = '...' + content;
    if (end < fileSize) content = content + '...';

    return content.trim();
  } catch (e) {
    console.warn(`[Coalesce] inflateSnippetFromDisk failed:`, e);
    return null;
  }
}

/**
 * Snap to sentence boundaries for cleaner snippets
 */
function snapToSentenceBoundaries(content: string, targetStart: number, targetEnd: number): { start: number, end: number, text: string } {
  // Snap start: find previous sentence end
  const preceding = content.substring(0, targetStart);
  const matchStart = preceding.match(/([.!?]\s|\n\s*\n)(?=[^.!?\n]*$)/);
  const snappedStart = matchStart && matchStart.index !== undefined
    ? matchStart.index + matchStart[0].length
    : 0;

  // Snap end: find next sentence end
  const succeeding = content.substring(targetEnd);
  const matchEnd = succeeding.match(/([.!?]\s|\n\s*\n)/);
  const snappedEnd = matchEnd && matchEnd.index !== undefined
    ? targetEnd + matchEnd.index + 1
    : content.length;

  return {
    start: snappedStart,
    end: snappedEnd,
    text: content.substring(snappedStart, snappedEnd).trim()
  };
}

/**
 * Format search results within character budget
 * Uses molecular coordinates (start_byte/end_byte) for precise content slicing
 *
 * Features:
 * - Coalesces nearby atoms into coherent snippets (500-1000 chars)
 * - Adds metadata headers with file, range, timestamp, atom count
 * - Sorts chronologically for causal narrative
 * - Wraps in XML with relevance scores for LLM prioritization
 */
export async function formatResults(
  results: SearchResult[],
  maxChars: number,
  options?: { enableCoalescing?: boolean; proximityThreshold?: number; }
): Promise<{ context: string; results: SearchResult[]; toAgentString: () => string; metadata?: any }> {
  try {
    const enableCoalescing = options?.enableCoalescing ?? true;
    const proximityThreshold = options?.proximityThreshold ?? 500;

    // Step 1: Coalesce atoms into coherent snippets
    let snippets: CoalescedSnippet[];
    let coalescingStats = { 
      original_atoms: results.length, 
      coalesced_snippets: results.length, 
      compression_ratio: 1.0 
    };

    if (enableCoalescing) {
      snippets = await coalesceByProximity(results, proximityThreshold);
      coalescingStats = {
        original_atoms: results.length,
        coalesced_snippets: snippets.length,
        compression_ratio: results.length > 0 ? (results.length / snippets.length) : 1.0
      };
    } else {
      // Convert SearchResult[] to CoalescedSnippet[] for uniform handling
      snippets = results.map(r => ({
        source: r.source,
        compoundId: r.compound_id || '',
        startByte: r.start_byte || 0,
        endByte: r.end_byte || 0,
        timestamp: r.timestamp,
        content: r.content,
        sourceAtoms: [r],
        relevanceScore: r.score,
        provenance: r.provenance || 'internal',
        tags: r.tags || []
      }));
    }

    // Step 2: Sort chronologically (causal narrative)
    snippets.sort((a, b) => a.timestamp - b.timestamp);

    // Step 3: Calculate temporal weights
    const now = Date.now();
    const lambda = 0.0001;

    const enrichedSnippets = snippets.map(s => {
      const ageMs = now - s.timestamp;
      const ageSeconds = ageMs / 1000;
      const decayFactor = lambda * ageSeconds;
      const temporalWeight = Math.exp(-decayFactor);
      const relevanceScore = (s.relevanceScore * temporalWeight).toFixed(3);

      return {
        ...s,
        temporal_weight: temporalWeight,
        decay_factor: decayFactor,
        weighted_score: relevanceScore
      };
    });

    // Step 4: Build XML-wrapped context with metadata headers
    const xmlContext = enrichedSnippets.map((s, idx) => {
      const timestamp = new Date(s.timestamp).toISOString();
      const persona = s.tags[0] || s.provenance || 'unknown';
      const atomCount = s.sourceAtoms.length;
      const charCount = s.content.length;
      const startHex = s.startByte.toString(16).toUpperCase().padStart(4, '0');
      const endHex = s.endByte.toString(16).toUpperCase().padStart(4, '0');
      const fileName = path.basename(s.source);

      // Metadata header for each snippet
      const header = `[GROUP:${idx + 1}] [File:${fileName}] [Range: 0x${startHex}-0x${endHex}] [Time: ${timestamp}] [Atoms: ${atomCount}] [Chars: ${charCount}]`;

      return `${header}
<atom id="${s.sourceAtoms.map(a => a.id.substring(0, 8)).join(',')}" relevance="${s.weighted_score}" timestamp="${timestamp}" persona="${persona}" source="${s.source}">
${s.content}
</atom>`;
    }).join('\n\n');

    // Step 5: Calculate budget allocation
    const totalContentChars = enrichedSnippets.reduce((sum, s) => sum + s.content.length, 0);
    const overheadChars = xmlContext.length - totalContentChars;
    const budgetUtilization = maxChars > 0 ? ((totalContentChars + overheadChars) / maxChars * 100).toFixed(1) : 'N/A';

    // Step 6: Convert snippets back to SearchResult[] for API compatibility
    const enrichedResults: SearchResult[] = enrichedSnippets.map(s => ({
      id: s.sourceAtoms.map(a => a.id).join('+'),
      content: s.content,
      source: s.source,
      timestamp: s.timestamp,
      buckets: [],
      tags: s.tags,
      epochs: '',
      provenance: s.provenance,
      score: s.relevanceScore,
      compound_id: s.compoundId,
      start_byte: s.startByte,
      end_byte: s.endByte,
      temporal_weight: s.temporal_weight,
      decay_factor: s.decay_factor,
      is_inflated: true
    }));

    return {
      context: xmlContext || 'No results found.',
      results: enrichedResults,
      toAgentString: () => {
        return enrichedSnippets.map(s =>
          `[${s.provenance}] ${s.source} (t=${s.temporal_weight.toFixed(3)}, atoms=${s.sourceAtoms.length}): ${s.content.substring(0, 200)}...`
        ).join('\n');
      },
      metadata: {
        coalescing: coalescingStats,
        budget_allocation: {
          total_chars: totalContentChars + overheadChars,
          content_chars: totalContentChars,
          overhead_chars: overheadChars,
          utilization_percent: parseFloat(budgetUtilization)
        },
        provenance_enabled: true,
        temporal_decay_lambda: lambda,
        xml_wrapped: true,
        chronological_sort: true
      }
    };
  } catch (error) {
    console.error('[Search] formatResults failed:', error);
    return {
      context: 'Error occurred during result formatting.',
      results: [],
      toAgentString: () => 'Error occurred during result formatting.',
      metadata: { error: true, message: 'Failed to format search results' }
    };
  }
}

/**
 * Helper to filter tags for display (User Request: Hide Year Numbers)
 */
export function filterDisplayTags(tags: string[]): string[] {
    if (!config.SEARCH?.hide_years_in_tags) return tags;
    // Remove if exactly 4 digits (approx year check)
    return tags.filter(t => !/^\d{4}$/.test(t));
}
